m = eval(input("Enter a number: "))
n = 0
while m>=n*n:
    n=n+1
print(n)