num = input("Enter an integer: ")
for i in range(len(num)):
    print(num[i])